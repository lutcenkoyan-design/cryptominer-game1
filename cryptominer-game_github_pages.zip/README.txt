
INSTALLATION ON iOS (iPhone / iPad):

1. Upload folder contents to any HTTPS hosting (GitHub Pages recommended).
2. Open the site in Safari.
3. Tap Share → Add to Home Screen.
4. The game will install as an offline-capable PWA.

INSTALLATION ON ANDROID:

1. Upload to any hosting OR run locally via Python server:
   python3 -m http.server
2. Open Chrome → menu → Install App.

This version includes:
- Crypto UI theme
- Neon gradients
- Mobile layout
- PWA offline mode
